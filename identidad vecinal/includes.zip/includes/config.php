<?php
/*
|--------------------------------------------------------------------------
| OWSA-INV V2
|--------------------------------------------------------------------------
| Author: Siamon Hasan
| Project Name: OSWA-INV
| Version: v2
| Offcial page: http://oswapp.com/
| facebook Page: https://www.facebook.com/oswapp
|
|
|
*/
  define( 'DB_HOST', '127.0.0.1' );// Set database host
  define( 'DB_USER', 'u761283263_ident' );// Set database user
  define( 'DB_PASS', 'ger6493003998297' );// Set database password
  define( 'DB_NAME', 'u761283263_iv' );// Set database name

?>  
